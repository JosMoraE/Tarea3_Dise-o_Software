package NotificacionesAdapter;

public class AdapterNotificadorCorreo {
    
}
