package NotificacionesAdapter;

public class NotificadorMensajeria {
    
}
