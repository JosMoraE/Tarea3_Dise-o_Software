package NotificacionesAdapter;

public class AdapterNotificadorSMS {
    
}
