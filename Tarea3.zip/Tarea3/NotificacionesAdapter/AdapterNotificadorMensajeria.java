package NotificacionesAdapter;

public class AdapterNotificadorMensajeria {
    
}
