package NotificacionesAdapter;

public interface Notificador {
    
}
