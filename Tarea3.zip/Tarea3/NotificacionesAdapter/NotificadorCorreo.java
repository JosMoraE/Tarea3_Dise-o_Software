package NotificacionesAdapter;

public class NotificadorCorreo {
    
}
