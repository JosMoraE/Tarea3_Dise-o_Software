package CabinaFactoryMethod;

public class CabinaFamiliarFactory {
    
}
