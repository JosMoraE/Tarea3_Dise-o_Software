package CabinaFactoryMethod;

public class SuiteFactory {
    
}
