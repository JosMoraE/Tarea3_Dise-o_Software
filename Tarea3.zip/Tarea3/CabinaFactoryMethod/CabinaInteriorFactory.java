package CabinaFactoryMethod;

public class CabinaInteriorFactory {
    
}
