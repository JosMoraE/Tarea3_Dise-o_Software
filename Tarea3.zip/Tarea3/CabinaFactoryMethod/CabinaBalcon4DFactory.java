package CabinaFactoryMethod;

public class CabinaBalcon4DFactory {
    
}
