package CabinaFactoryMethod;

public class CabinaSuite {
    
}
