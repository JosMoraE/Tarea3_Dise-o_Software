package CabinaFactoryMethod;

public enum EstadoCabina {
    Disponible,
    Reservado,
    Ocupada,
    En_Mantenimiento
}
