package CabinaFactoryMethod;

public class CabinaBalcon {
    
}
