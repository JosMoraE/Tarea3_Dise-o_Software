package CabinaFactoryMethod;

public class CabinaInterior {
    
}
