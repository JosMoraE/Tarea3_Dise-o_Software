package CabinaFactoryMethod;

public class CabinaFactory {
    
}
