package CabinaFactoryMethod;

public class CabinaFamiliar {
    
}
