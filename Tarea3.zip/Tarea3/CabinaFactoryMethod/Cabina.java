package CabinaFactoryMethod;

public abstract class Cabina {
    protected int n_cabina;
    protected EstadoCabina estado;
    protected int precio;
    
    public Cabina(int n_cabina, EstadoCabina estado, int precio){
        this.n_cabina = n_cabina;
        this.precio = precio;
        this.estado = EstadoCabina.Disponible;
    }

    public abstract double calcularPrecio(); //Cada cabina se encargara de mandar su precio respectivo


    public int getN_cabina() {
        return n_cabina;
    }

    public EstadoCabina getEstado() {
        return estado;
    }

    public int getPrecio() {
        return precio;
    }
    

    public void setN_cabina(int n_cabina) {
        this.n_cabina = n_cabina;
    }

    public void setEstado(EstadoCabina estado) {
        this.estado = estado;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }


}
