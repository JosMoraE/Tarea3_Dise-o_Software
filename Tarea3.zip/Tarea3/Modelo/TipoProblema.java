package Modelo;

public enum TipoProblema {
    Leve,
    Critico
    
}
