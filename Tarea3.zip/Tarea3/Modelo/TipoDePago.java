package Modelo;

public enum TipoDePago {
    Efectivo,
    TarjetaDeCredito,
    TarjetaDeDebito
}
