package Modelo;
import CabinaFactoryMethod.Cabina;
import java.util.*;

public class Reserva {
    private Usuario usuario;
    private List<Cabina> cabinas;
    private List<Servicios> servicios;

    public Reserva(Usuario usuario, List<Cabina> cabinas, List<Servicios> servicios){
        this.usuario = usuario;
        this.cabinas = cabinas;
        this.servicios = servicios;
    }
    public double calcularCostoTotal(){
        double costoTotal = 0.0;
        for (Cabina cabina : cabinas) {
            costoTotal += cabina.calcularPrecio();
        }
        
        // Sumar costo de servicios
        for (Servicios servicio : servicios) {
            costoTotal += servicio.getPrecio();
        }

        System.out.println("💰 Costo total calculado: $" + costoTotal);
        return costoTotal;
    }



    public Usuario getUsuario() {
        return usuario;
    }

    public List<Cabina> getCabinas() {
        return cabinas;
    }

    public List<Servicios> getServicios() {
        return servicios;
    }


}
