package Modelo;

public class Crucero {
    private int capacidad;
    private int duracion_viaje;

    public Crucero(int capacidad, int duracion_viaje){
        this.capacidad = capacidad;
        this.duracion_viaje = duracion_viaje;
    }

    
    public int getCapacidad() {
        return capacidad;
    }

    public int getDuracion_viaje() {
        return duracion_viaje;
    }

    
}
