package Modelo;

public enum EstadoProblema {
    Abierto,
    Cerrado,
    Resuelto
}
