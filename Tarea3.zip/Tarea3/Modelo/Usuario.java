package Modelo;
import java.util.*;
import ProblemChainOfR.*;

import CabinaFactoryMethod.Cabina;

public class Usuario {
    private String nombre;
    private int ID;
    private Pago pago;

    public Usuario(String nombre, int ID,Pago pago){
        this.nombre = nombre;
        this.ID = ID;
        this.pago = pago;
    }
    public Reserva hacerReservas(Crucero crucero, List<Cabina> cabinas, List<Servicios> servicios){
        System.out.println("Realizando reserva por usuario : " + nombre + " con ID: " + ID);
        Reserva reserva = new Reserva(this,cabinas, servicios);

        reserva.calcularCostoTotal();
        return reserva;
    }

    public void reportarProblemas(Problema p, HandlerReporte hr){
        System.out.println("Problema sera atendido en breve");
        hr.atenderReporte(p);
    }

    public void realizarPago(){
        System.out.println("Usuario: " + nombre + " ha pagado la cantidad de: " + pago.getMonto() + " con: " + pago.getTipo());
    }

    public String getNombre() {
        return nombre;
    }

    public int getID() {
        return ID;
    }

    public Pago getPago() {
        return pago;
    }



}
