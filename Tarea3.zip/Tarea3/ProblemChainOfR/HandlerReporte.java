package ProblemChainOfR;

import Modelo.EstadoProblema;
import Modelo.Problema;

public abstract class HandlerReporte{
    protected HandlerReporte hr;
    protected String nombre;
    protected int ID;

    public HandlerReporte(String nombre, int ID){
        this.nombre = nombre;
        this.ID = ID;
    }

    public void setNext(HandlerReporte h) {
        this.hr = h;
    }
    
    public abstract void atenderReporte(Problema p);
    
    // Método auxiliar para transferir al siguiente handler
    protected void transferirAlSiguiente(Problema problema) {
        if (hr != null) {
            System.out.println("   → [" + nombre + "] Transfiriendo al siguiente nivel...");
            hr.atenderReporte(problema);
        } else {
            System.out.println("  X [" + nombre + "] No hay más niveles para manejar el reporte");
            problema.setEstado(EstadoProblema.Cerrado); // Se cierra sin resolver
        }
    }
    
    // Getters
    public String getNombre(){
        return nombre;
    }

    public int getID(){
        return ID; 
    }
    
    public HandlerReporte getNextHandler(){ 
        return hr;
    }
}