package ProblemChainOfR;
import Modelo.*;

public class GerenciaCrucero extends HandlerReporte {
    
    public GerenciaCrucero() {
        super("Gerencia de Crucero", 1);
    }
    
    @Override
    public void atenderReporte(Problema p) {
        System.out.println("\n [GERENCIA CRUCERO] ID: " + ID + " - Procesando problema: " + p);
        
        // La gerencia puede manejar problemas críticos
        if (p.getTipo() == TipoProblema.Critico) {
            System.out.println("  [" + nombre + "] Problema crítico resuelto con autoridad ejecutiva");
            p.setEstado(EstadoProblema.Resuelto);
            
            // Acciones específicas para problemas críticos
            manejarProblemaCritico(p);
            
        } else if (p.getTipo() == TipoProblema.Leve) {
            System.out.println("   [" + nombre + "] Problema leve resuelto rápidamente");
            p.setEstado(EstadoProblema.Resuelto);
            
        } else {
            System.out.println("   [" + nombre + "] No se puede determinar el tipo de problema");
            transferirAlSiguiente(p);
        }
    }
    
    private void manejarProblemaCritico(Problema p) {
        System.out.println("Activando protocolo de emergencia");
        System.out.println("Contactando autoridades pertinentes");
        System.out.println("Notificando a stakeholders");
        System.out.println("Autorizando compensaciones excepcionales");
    }
}